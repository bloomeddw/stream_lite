# Codex Destructive Operation Rules

## Purpose

This document defines repository-safety rules for Stream Lite implementation agents. It exists because a completed Codex session reported that verification had passed and then a later cleanup step removed repository files. These rules prevent cleanup from becoming destructive work.

## Related requirements

- `SL-REQ-003`: every requirements-changing patch includes a worklog.
- `SL-DECOMP-010`: implementation planning does not assign code tasks until contracts are defined.
- `SL-VER-031`: readiness gates require contract lint, schema validation, Sphinx where applicable, and recorded gaps.

## Required agent files

- `AGENTS.md` at the repository root is the first file agents must read.
- `.codex/RULES.md` contains Codex-specific safety rules.
- This document is the human-readable implementation reference for destructive-operation prevention.

## Non-negotiable rules

1. Agents SHALL NOT run broad recursive delete commands from the repository root.
2. Agents SHALL NOT use repository reset commands as a cleanup mechanism.
3. Agents SHALL NOT delete `.venv/` from a user working copy.
4. Agents SHALL NOT delete source, docs, schemas, tests, migrations, requirements, `.env.example`, or worklogs during packaging.
5. Agents SHALL create zip patches from explicit changed-file include lists instead of cleaning the full working tree.
6. Agents SHALL record exact verification commands and results before final handoff.
7. Agents SHALL stop if unexpected deleted files appear in `git status --short`.

## Forbidden command examples

The following command shapes are forbidden unless the user explicitly requests destructive recovery and names the exact target:

```text
rm -rf .
rm -rf *
git clean -fdx
git reset --hard
Remove-Item -Recurse
rd /s
rmdir /s
del /s
Get-ChildItem -Recurse | Remove-Item
find . -delete
find . -exec rm
```

Equivalent aliases, scripts, and shell pipelines are also forbidden.

## Safe packaging approach

Use an explicit file list for the patch. Example intent:

```text
zip patch.zip AGENTS.md .codex/RULES.md docs/implementation/CODEX_DESTRUCTIVE_OPERATION_RULES.md docs/worklogs/WORKLOG-YYYYMMDD-topic.md
```

Inspect the zip contents. Do not delete the repository to remove generated files from the archive.

## Allowed generated-artifact exclusion list

Generated artifacts may be excluded from packaging. If removal is absolutely necessary, only exact paths may be removed after inspection:

```text
docs/_build/
.pytest_cache/
__pycache__/
*.pyc
.tmp/
tmp/
.pytest_vendor/
pytest_vendor/
wheelhouse/
pytest-cache-files-*/
```

Removal of `.venv/` from a user working copy is not allowed. Exclude it from packaging instead.

## Recovery checklist

If accidental deletion occurs:

1. Stop all implementation work.
2. Capture current path and status:
   - `pwd`
   - `git status --short`
   - `git status --ignored --short`
3. Capture the last destructive command if available.
4. Restore from the latest known-good zip/source control.
5. Reapply only the intended patch files.
6. Add a worklog describing the incident and recovery evidence.

## Acceptance criteria

This safety layer is accepted when:

- `AGENTS.md` exists at repository root.
- `.codex/RULES.md` exists.
- `docs/implementation/CODEX_DESTRUCTIVE_OPERATION_RULES.md` is linked from implementation docs.
- `docs/worklogs/INDEX.md` includes the guardrail worklog.
- `python -S tools/contract_lint.py --write-inventory` passes.
