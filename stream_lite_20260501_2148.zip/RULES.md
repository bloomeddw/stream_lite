# Stream Lite Codex Safety Rules

These rules exist to prevent accidental repository deletion and high-token, high-risk cleanup behavior. They are subordinate to user instructions only when the user explicitly asks for destructive recovery and names the exact files or directories to remove.

## 1. Work in small, reversible patches

- Change only the files required by the current work package.
- Prefer direct edits to named files over generated rewrites.
- Do not reformat unrelated files.
- Do not include prompts in zip patches.
- Always add or update a worklog for non-trivial changes.

## 2. No broad deletion

Forbidden commands and patterns:

```text
rm -rf .
rm -rf *
rm -rf stream_lite
git clean -fd
git clean -fdx
git reset --hard
Remove-Item -Recurse
Remove-Item -Force -Recurse
rd /s
rmdir /s
del /s
Get-ChildItem -Recurse | Remove-Item
find . -delete
find . -exec rm
```

Do not run any equivalent command, alias, script, or shell pipeline from the repo root.

## 3. Packaging without deleting

To exclude generated artifacts from a zip, build the zip from an explicit include list. Do not delete the working tree first.

Safe include categories:

```text
AGENTS.md
.codex/RULES.md
app/**/*.py
schemas/**/*.json
tests/**/*.py
docs/**/*.md
docs/**/*.rst
docs/conf.py
docs/Makefile
tools/**/*.py
requirements*.txt
.env.example
alembic.ini
```

Unsafe include categories:

```text
.venv/**
__pycache__/**
*.pyc
.pytest_cache/**
docs/_build/**
.pytest_vendor/**
pytest_vendor/**
wheelhouse/**
.tmp/**
tmp/**
pytest-cache-files-*/**
```

## 4. Verification before cleanup

Run required tests first. If tests pass, record the exact commands and results in the worklog. After packaging, inspect the zip contents instead of deleting repository files.

Minimum checks for patch packaging:

```text
python -S tools/contract_lint.py --write-inventory
zip content listing proves no generated/cache/vendor artifacts are included
```

## 5. Context-budget discipline

To avoid wasting Codex time:

- Read the specific files named by the work package first.
- Do not dump large docs into the prompt or terminal output.
- Use targeted search such as `grep`, `Select-String`, or opening narrow line ranges.
- Stop and ask for a smaller task if the task spans multiple work packages.

## 6. Recovery if damage occurs

If source files, docs, schemas, tests, migrations, or worklogs disappear:

1. Stop immediately.
2. Do not attempt to recreate the entire repo from memory.
3. Report the exact last action and current file status.
4. Restore from the latest known-good zip/source control before applying any new patch.
5. Add a recovery worklog once the repo is restored.
