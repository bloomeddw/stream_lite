# Stream Lite Agent Instructions

These instructions apply to the entire repository. They are mandatory for Codex, ChatGPT, shell agents, and any automated implementation helper working inside this repo.

## Prime directive

Stream Lite is requirements-first and patch-first. Do not perform broad cleanup, broad deletion, or destructive repository reset operations. A coding task is not complete until the repository remains intact, tests are reported, generated artifacts are excluded from the deliverable, and a worklog is written.

## Required reading before code changes

Before modifying files, read:

1. `rtc_source.md` when present beside or inside the repo.
2. `docs/implementation/CODEX_TASK_GUIDE.md`.
3. `.codex/RULES.md`.
4. The current work-package reference under `docs/implementation/wp_reference/`.
5. The owning requirement files for the work package.

If any of these files are missing after a destructive operation, stop and report recovery steps instead of continuing.

## Destructive-command ban

Never run any command that can recursively delete or reset the repository, including but not limited to:

- `rm -rf .`, `rm -rf *`, `rm -rf stream_lite`, or any repo-root recursive delete.
- `git clean -fd`, `git clean -fdx`, `git reset --hard`, or `git checkout .` unless the user explicitly asks for recovery and names the exact target.
- PowerShell `Remove-Item -Recurse`, `Remove-Item -Force -Recurse`, `rd /s`, `rmdir /s`, `del /s`, or `Get-ChildItem -Recurse | Remove-Item` from the repo root.
- `find . -delete`, `find . -exec rm`, or equivalent broad delete pipelines.
- Docker or system prune commands such as `docker system prune`, `docker volume prune`, or commands that remove local data volumes.

Generated artifacts must be excluded from zip patches, not removed from the working tree with broad deletes.

## Safe cleanup policy

Allowed cleanup is limited to exact known generated paths, and only after `git status --short` or equivalent file listing has been reviewed:

- `docs/_build/`
- `.pytest_cache/`
- `__pycache__/`
- `*.pyc`
- `.tmp/`
- `tmp/`
- `.pytest_vendor/`
- `pytest_vendor/`
- `wheelhouse/`
- `pytest-cache-files-*`

Do not delete `.venv/` from the user's working copy. Do not delete `app/`, `docs/`, `schemas/`, `tests/`, `tools/`, `.env.example`, requirements files, migrations, or worklogs.

For packaging, prefer creating a patch zip from an explicit include list of changed source/docs/test files. Do not clean the whole repository to make a zip.

## Patch and worklog requirements

Every non-trivial change must include a worklog under `docs/worklogs/` with:

- summary
- files changed
- requirements affected
- decisions applied
- tests or verification commands run
- assumptions
- gaps
- rollback notes
- next step

Prompts do not go in zip patches. Show prompts only in chat or external handoff text.

## Stop conditions

Stop immediately and report instead of continuing if:

- A command would delete more than the exact generated artifact paths listed above.
- `git status --short` shows unexpected deleted source, docs, schema, test, migration, or worklog files.
- The current task would need a new environment variable, API route, schema, event, migration, metric, state transition, or Streamlit control that is not requirements-backed.
- The work-package prompt conflicts with `AGENTS.md` or `.codex/RULES.md`.
- Tests pass only before cleanup but files are missing after cleanup.

## Incident recovery rule

If files are deleted unexpectedly:

1. Stop all implementation work.
2. Do not run more cleanup commands.
3. Capture `pwd`, `git status --short`, `git status --ignored --short`, and the last destructive command if known.
4. Create or update a recovery worklog under `docs/worklogs/` if the repo is still writable.
5. Ask the user to restore from the latest known-good zip or source control before reapplying changes.
